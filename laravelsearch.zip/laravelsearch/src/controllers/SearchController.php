<?php

namespace GlobalLaravelSearch\Controllers;

use App\User;
use DB;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Config;
use Illuminate\Http\Request;


class SearchController extends Controller
{
	public function getIndex(){
		return view('Views::search');
	}

	public function getSearchData(Request $request){
		$this->validate($request, [
        	'search' => 'required|min:3',
     	]);
		$postvalue = $request->input('search');
		//Get table settings here
		$table = Config::get('search.tables_and_columns');
		$data['table'] = $table;
		//Reterive all data show search query implmented easily
		foreach($table as $key => $col){
			$tablearray[$key] = explode(',',$col);
		}
         
		//Get data from all tables
		foreach($tablearray as $key => $colval){
			$data[$key] = $this::FindData($colval ,$postvalue,$key);
		}

		//Set images array here according to table
		$data['photos'] = Config::get('search.images_field');
        $data['staticImagePath'] = Config::get('search.assets_images'); 
		dd($data);
		return view('Views::searchresult',$data);
		
	}


	public static function FindData($colval, $postvalue, $table){
		
		$query = DB::table($table);

		foreach($colval as $key => $values){
		  $query ->orWhere($values ,'like', '%'.$postvalue.'%');
		}
		
		//Get site_routes and images  settings here
		$site_routes     = Config::get('search.site_routes');
		$site_images     = Config::get('search.site_images');
        $site_encrypt    = Config::get('search.site_encrypt');
        
		$result = $query->get();

		for($i = 0; $i < count($result); $i++){
	        if(isset($site_routes) && isset($site_images) && isset($site_encrypt)){
	            $result[$i]->site_routes  = $site_routes[$table];
	            $result[$i]->site_images  = $site_images[$table];
	            $result[$i]->site_encrypt = $site_encrypt[$table];
	        }
        }
        return $result ;
	}
		
}
