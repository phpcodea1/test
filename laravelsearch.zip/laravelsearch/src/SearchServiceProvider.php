<?php 
namespace GlobalLaravelSearch;

use Illuminate\Support\ServiceProvider;

class SearchServiceProvider extends ServiceProvider {

  
   /**
     * Bootstrap the application services.
     *
     * @return void
    */
  public function boot()
  {   
        
        $this->publishes([__DIR__.'/public/images' => public_path('/vendor/durga/laravelsearch/assets/images'),], 'search_assets');

        $this->publishes([__DIR__.'/public/css' => public_path('/vendor/durga/laravelsearch/assets/css'),], 'search_assets');

        //Publishes package config file to applications config folder
        $this->publishes([__DIR__.'/config/search.php' => config_path('search.php')]);

        
   }

  /**
    * Register the application services.
    *
    * @return void
  */
  public function register()
  {
    
    //Include Routes files her for package
    include __DIR__.'/routes.php';
    $this->loadViewsFrom(__DIR__.'/views', 'Views');
  }

}
