<?php

Route::group(["middleware" => "web"], function(){
	
	Route::controllers([
		"globalsearch"      		=> "GlobalLaravelSearch\controllers\SearchController"
	]);

});
