<?php 
namespace GlobalLaravelSearch\Models;

use Illuminate\Database\Eloquent\Model;

class SearchModel extends Model  
{
  protected $table ='';
  
  public static function FindData($colname){

  	return $colname;
  }
}

