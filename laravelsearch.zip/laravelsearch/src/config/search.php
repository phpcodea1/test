<?php

return [
    
    /*******************
        Cofigration setting for search template 
        Here you can set your master layout for pages
    *******************/
    'master_file_extend' => '',

    /*******************
        Here you can set tables and to get data you can add 
    *******************/
    'tables_and_columns' =>[
                         /* You can set these multiple times */
                        '' => ''
    ],
    

    /*******************
       Here you can set site routes for particular table Single View.. 
    *******************/
    'site_routes' =>[
                         /* You can set these multiple times */
                        '' => '',
    ],

    
    /*******************
        Here you can set site routes for particular table Single View ID Bycrypt.. Use True and False for it
    *******************/
    'site_encrypt' =>[
                         /* You can set these multiple times */
                        '' => ,
    ],

    
    /*******************
        Here you can set site routes for particular table Single View photos..  
    *******************/
    'site_images' =>[
                         /* You can set these multiple times */
                        '' => '',
    ],

    /*******************
        Here you can set Images field which you want to display with short description  
    *******************/
    'images_field' =>[
                         /* You can set these multiple times with different  table names with one field*/
                        '' => '',
    ],

];

?>