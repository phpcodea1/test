@extends(Config::get('search.master_file_extend'))
<link rel="stylesheet" type="text/css" href="{{ asset('/public/vendor/durga/laravelsearch/assets/css/search.css') }}">
@section('body_class','innerpage signup')
@section('content')
<div class="full-width width-full">
	<div class="main-container clearfix">
	
	    <div class="content"> 
	      <form class="searchform cf" method="get" action="{{ url('globalsearch/search-data') }}">
			  <input type="text" placeholder="Is it me you’re looking for?" name="search">
                          {{ csrf_field() }}
			  <button type="submit">Search</button>
		</form>
	    </div>
	</div>
</div>
@stop