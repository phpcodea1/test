@extends(Config::get('search.master_file_extend'))
<link rel="stylesheet" type="text/css" href="{{ asset('/public/vendor/durga/laravelsearch/assets/css/search.css') }}">
@section('body_class','innerpage signup')
@section('breadcrumb_title','Search Result')
@section('content')
<div class="full-width width-full">
	<div class="main-container clearfix">
		<div class="container">
			<div id="blog" class="row"> 
			@foreach($table as $key => $column)
                
			    @php 
			       
			        $colArray = explode(',',$column);
			        $tableData = ${$key};
			        
			    @endphp
			    @foreach($tableData as $datakey => $values)
			     
			    <div class="col-md-10 blogShort">
				        @foreach($photos as $photokey => $photodata)
				            @php 
						 		$photoArray =  array_filter(explode(',',$photodata));
						 	@endphp
							 	@foreach($photoArray as $photovalue) 
							 	    @php 
							 	    if(isset($values->$photovalue)){
							 	        if(($values->site_images && $values->$photovalue) != NULL){
							 	        	$url = htmlentities(env('APP_URL').'/'.$values->site_images.$values->$photovalue);
							 	        }else{
							 	            $url = asset('/public/vendor/durga/laravelsearch/assets/images/notfound.jpg');
							 	        }   	
							 	    }
							 	    @endphp
							 	    
					         		<div class="search-img">
					         		@if(isset($url))
					         		 <img src="{{ $url }}" alt="post img" class="pull-left img-responsive thumb margin10 img-thumbnail"/>
					         		@php
                                       unset($url);
                                       
                                    @endphp                                 
					         		@endif
					         		</div>
					            @endforeach
				         @endforeach
				         <div class="search-txt">
			         @foreach($colArray as $colvalues)
			         <article>
			         	<p>{{ strip_tags(str_limit($values->$colvalues,'350',$end ='...')) }}</p>
			         </article>			        
			         @endforeach
			         @php 
			         	if($values->site_encrypt == 1){
			         	   $postId = Crypt::encrypt($values->id);
			         	}
			         	else{
						   $postId = $values->id;
			         	}
			         @endphp
			         @if($values->site_routes != NULL)
			         <div class="search-btn"><a class="btn btn-blog pull-right marginBottom10" href="@if(!empty($values->site_routes)){{ env('APP_URL').'/'.$values->site_routes.$postId }} @endif">READ MORE</a> </div>
			         @else
			         <div class="search-btn"><a class="btn btn-blog pull-right marginBottom10" href="{{ env('APP_URL').'/'.strtolower(str_replace(' ','-',$values->title)) }}">READ MORE</a> </div>

			         @endif
			          </div>
			     </div>
			     @endforeach
			@endforeach
			</div>
		</div>
	</div>
</div>
@stop